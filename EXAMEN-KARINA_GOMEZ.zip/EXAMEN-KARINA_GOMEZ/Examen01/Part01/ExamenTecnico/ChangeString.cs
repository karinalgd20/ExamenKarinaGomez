﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenTecnico
{
    public class ChangeString
    {
        public String Build(String sParametro)
        {

            String[] sAbecedario = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "ñ", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            int total = sParametro.Length;
            
            String sBusca = "";
            String sResultado = "";
            int indice = 0;
            for (int i = 0; i < total; i++)
            {
                sBusca = sParametro.Substring(i, 1);
                indice = Array.IndexOf(sAbecedario, sBusca.ToLower());
                if (indice >= 0)
                {
                    int iValida = ASCIIEncoding.Unicode.GetBytes(sBusca)[0];
                    if (iValida <= 91 || iValida ==209)
                    {
                        sBusca = sAbecedario[indice+1].ToUpper();
                    }
                    else {
                        sBusca = sAbecedario[indice + 1];
                    }
                    sResultado = sResultado + sBusca;
                }
                else {
                    sResultado = sResultado + sBusca;
                }
                
            }

            return sResultado;
        }
    }
}
