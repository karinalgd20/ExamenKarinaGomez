﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenTecnico
{
    public class CompleteRange
    {

        public int[] Build(int[] Range)
        {
            int maximo = Range.Max();
            int[] Resultado = new int[maximo];

            for (int i = 1; i <= maximo; i++)
            {
                Resultado[(i-1)] = i;
            }

            return Resultado;
        }
    }
}
