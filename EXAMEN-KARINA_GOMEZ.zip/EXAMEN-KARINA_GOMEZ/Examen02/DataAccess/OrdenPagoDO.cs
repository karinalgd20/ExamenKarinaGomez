﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using Examen02.Models;
using System.Configuration;
using System.Data.Common;
using System.Reflection;
using System.Runtime.Serialization; 


namespace Examen02.DataAccess
{
    public class OrdenPagoDO
    {
        #region Variables

        DatabaseProviderFactory factory = new DatabaseProviderFactory();
        Util util = new Util();

        #endregion

        #region Metodos

        public List<OrdenPago> GetOrdenPagoList()
        {
            List<OrdenPago> objGetOrdenPago = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_ORDEN_PAGO");

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetOrdenPago = util.ConvertTo<OrdenPago>(dataTable);
            }

            return objGetOrdenPago;
        }

        public List<OrdenPago> GetOrdenPagoByMonedaList(String Moneda)
        {
            List<OrdenPago> objGetOrdenPago = null;
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_ORDEN_MONEDA");

            db.AddInParameter(cmd, "@MONEDA", DbType.String, Moneda);

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetOrdenPago = util.ConvertTo<OrdenPago>(dataTable);
            }

            return objGetOrdenPago;
        }


        public OrdenPago GetOrdenPagoListById(int IdOrdenPago)
        {
            OrdenPago objGetOrdenPago = new OrdenPago();
            var db = factory.Create("Cn");
            var ds = new DataSet();
            var cmd = db.GetStoredProcCommand("SP_LISTA_ORDEN_PAGO_ID");

            db.AddInParameter(cmd, "@ID", DbType.Int32, IdOrdenPago);

            using (DataTable dataTable = db.ExecuteDataSet(cmd).Tables[0])
            {
                objGetOrdenPago.IdOrdenesPago = int.Parse(dataTable.Rows[0]["IdOrdenesPago"].ToString());
                objGetOrdenPago.IdSucursal = int.Parse(dataTable.Rows[0]["IdSucursal"].ToString());
                objGetOrdenPago.Monto = decimal.Parse(dataTable.Rows[0]["Monto"].ToString());
                objGetOrdenPago.Moneda = dataTable.Rows[0]["Moneda"].ToString();
                objGetOrdenPago.IdEstado = int.Parse(dataTable.Rows[0]["IdEstado"].ToString());
                objGetOrdenPago.FecPago = DateTime.Parse(dataTable.Rows[0]["FecPago"].ToString());
            }

            return objGetOrdenPago;
        }


        public void Mant(OrdenPago oEnt, int Opcion)
        {
            var db = factory.Create("Cn");

            db.ExecuteNonQuery("SP_MANT_ORDEN_PAGO", new object[] { oEnt.IdOrdenesPago, oEnt.IdSucursal, oEnt.Monto,oEnt.Moneda,oEnt.IdEstado, oEnt.FecPago, Opcion });
        }

        #endregion


    }
}