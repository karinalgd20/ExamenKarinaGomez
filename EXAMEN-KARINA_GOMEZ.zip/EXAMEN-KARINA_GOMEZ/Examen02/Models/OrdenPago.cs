﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Examen02.Models
{
    public class OrdenPago
    {
        [Key]
        public int IdOrdenesPago { get; set; }

        public decimal Monto { get; set; }

        [DataType(DataType.Currency)]
        public String Moneda { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha Pago")]
        public DateTime FecPago { get; set; }

        [Display(Name = "Sucursal")]
        public int IdSucursal { get; set; }

        [Display(Name = "Estado")]
        public int IdEstado { get; set; }

        [Display(Name = "Estado")]
        [NotMapped]
        public String Descripcion { get; set; }

        [Display(Name = "Sucursal")]
        [NotMapped]
        public String Sucursal { get; set; }

        [NotMapped]
        public bool Soles { get; set; }

        [NotMapped]
        public bool Dolares { get; set; }

    }
}