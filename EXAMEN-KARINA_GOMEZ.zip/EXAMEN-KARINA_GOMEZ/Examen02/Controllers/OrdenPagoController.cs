﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Examen02.DataAccess;
using System.Data;
using Examen02.Models;

namespace Examen02.Controllers
{
    public class OrdenPagoController : Controller
    {
        //
        // GET: /OrdenPago/
        OrdenPagoDO db = new OrdenPagoDO();
        SucursalDO objSuc = new SucursalDO();
        EstadoDO objEst = new EstadoDO();

        public ActionResult Index()
        {
            return View(db.GetOrdenPagoList());
        }

        //
        // GET: /OrdenPago/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /OrdenPago/Create

        public ActionResult Create()
        {
            ViewBag.IdSucursal = new SelectList(objSuc.GetSucursalList(), "IdSucursal", "Nombre");
            ViewBag.IdEstado = new SelectList(objEst.GetEstadoList(), "IdEstado", "Descripcion");
            return View();
        }

        //
        // POST: /OrdenPago/Create

        [HttpPost]
        public ActionResult Create(OrdenPago obOrdenPago)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    db.Mant(obOrdenPago, 1);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /OrdenPago/Edit/5

        public ActionResult Edit(int id)
        {
            OrdenPago objOrdenPago = new OrdenPago();
            objOrdenPago = db.GetOrdenPagoListById(id);

            ViewBag.IdSucursal = new SelectList(objSuc.GetSucursalList(), "IdSucursal", "Nombre", objOrdenPago.IdSucursal);
            ViewBag.IdEstado = new SelectList(objEst.GetEstadoList(), "IdEstado", "Descripcion", objOrdenPago.IdEstado);

            if (objOrdenPago.Moneda.Equals("$")) 
            {
                ViewBag.Soles = "false";
            }
            else {
                ViewBag.Soles = "true";
            }

            return View(objOrdenPago);
        }

        //
        // POST: /OrdenPago/Edit/5

        [HttpPost]
        public ActionResult Edit(OrdenPago obOrdenPago)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    obOrdenPago.FecPago = DateTime.Today;
                    ViewBag.IdSucursal = new SelectList(objSuc.GetSucursalList(), "IdSucursal", "Nombre", obOrdenPago.IdSucursal);
                    ViewBag.IdEstado = new SelectList(objEst.GetEstadoList(), "IdEstado", "Descripcion", obOrdenPago.IdEstado);
                    db.Mant(obOrdenPago, 2);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /OrdenPago/Delete/5

        public ActionResult Delete(int id)
        {
            OrdenPago objOrdenPago = new OrdenPago();
            objOrdenPago = db.GetOrdenPagoListById(id);

            ViewBag.IdSucursal = new SelectList(objSuc.GetSucursalList(), "IdSucursal", "Nombre", objOrdenPago.IdSucursal);
            ViewBag.IdEstado = new SelectList(objEst.GetEstadoList(), "IdEstado", "Descripcion", objOrdenPago.IdEstado);

            return View(objOrdenPago);
        }

        //
        // POST: /OrdenPago/Delete/5

        [HttpPost]
        public ActionResult Delete(OrdenPago obOrdenPago)
        {
            try
            {
                // TODO: Add delete logic here
                if (ModelState.IsValid)
                {
                    ViewBag.IdSucursal = new SelectList(objSuc.GetSucursalList(), "IdSucursal", "Nombre", obOrdenPago.IdSucursal);
                    ViewBag.IdEstado = new SelectList(objEst.GetEstadoList(), "IdEstado", "Descripcion", obOrdenPago.IdEstado);
                    db.Mant(obOrdenPago, 3);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
