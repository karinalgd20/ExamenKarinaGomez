﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml;
using System.Xml.Linq;
using Examen02.DataAccess;
using Examen02.Models;

namespace Examen02.Controllers
{
    public class XmlController : ApiController
    {
        SucursalDO db = new SucursalDO();
        // GET api/xml
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/xml/5
        public string Get(int id)
        {
            List<Sucursal> list = new List<Sucursal>();
            list = db.GetSucursalByBanco(id);

            var xEle = new XElement("Sucursales",
                from s in list
                select new XElement("Sucursal",
                             new XElement("IdSucursal", s.IdSucursal),

                               new XElement("Banco", new XElement("IdBanco", s.IdBanco), new XElement("Banco", s.Banco)),
                               new XElement("Nombre", s.Nombre),
                               new XElement("Direccion", s.Direccion),
                               new XElement("FecRegistro", s.FecRegistro)
                               
                           ));

            //xEle.Save("D:\\Sucursales.xml");

            return xEle.ToString() + " Ruta: C:\\Sucursales.xml";
        }

        [HttpGet, ActionName("SucursalXml")]
        public string SucursalXml(int id)
        {
            List<Sucursal> list = new List<Sucursal>();
            list = db.GetSucursalByBanco(id);

            var xEle = new XElement("Sucursales",
                from s in list
                select new XElement("Sucursal",
                             new XElement("IdSucursal", s.IdSucursal),

                               new XElement("Banco", new XElement("IdBanco", s.IdBanco), new XElement("Banco", s.Banco)),
                               new XElement("Nombre", s.Nombre),
                               new XElement("Direccion", s.Direccion),
                               new XElement("FecRegistro", s.FecRegistro)

                           ));

            return xEle.ToString();
        }

        // POST api/xml
        public void Post([FromBody]string value)
        {
        }

        // PUT api/xml/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/xml/5
        public void Delete(int id)
        {
        }
    }
}
