﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Examen02.DataAccess;
using System.Data;
using Examen02.Models;

namespace Examen02.Controllers
{
    public class BancoController : Controller
    {
        //
        // GET: /Banco/


        BancoDO db = new BancoDO();

        public ActionResult Index()
        {
            
            return View(db.GetBancoList());
        }

        //
        // GET: /Banco/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Banco/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Banco/Create

        [HttpPost]
        public ActionResult Create(Banco obBanco)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid) {
                    
                    db.Mant(obBanco, 1);

                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Banco/Edit/5

        public ActionResult Edit(int id)
        {
            Banco objBanco = new Banco();

            objBanco = db.GetBancoListById(id);

            ViewBag.FecRegistro = objBanco.FecRegistro;
            return View(objBanco);
        }

        //
        // POST: /Banco/Edit/5

        [HttpPost]
        public ActionResult Edit(Banco obBanco)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    obBanco.FecRegistro = DateTime.Today;
                    db.Mant(obBanco, 2);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Banco/Delete/5

        public ActionResult Delete(int id)
        {
            Banco objBanco = new Banco();
            objBanco = db.GetBancoListById(id);
            return View(objBanco);
        }

        //
        // POST: /Banco/Delete/5

        [HttpPost]
        public ActionResult Delete(Banco obBanco)
        {
            try
            {
                // TODO: Add delete logic here
                if (ModelState.IsValid)
                {
                    db.Mant(obBanco, 3);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
