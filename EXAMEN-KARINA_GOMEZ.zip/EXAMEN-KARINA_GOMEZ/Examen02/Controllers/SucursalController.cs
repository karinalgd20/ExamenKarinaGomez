﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Examen02.DataAccess;
using Examen02.Models;

namespace Examen02.Controllers
{
    public class SucursalController : Controller
    {
        //
        // GET: /Sucursal/
        SucursalDO db = new SucursalDO();
        BancoDO objBanco = new BancoDO();

        public ActionResult Index()
        {
            return View(db.GetSucursalList());
        }

        //
        // GET: /Sucursal/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Sucursal/Create

        public ActionResult Create()
        {
            ViewBag.IdBanco = new SelectList(objBanco.GetBancoList(), "IdBanco", "Nombre");
            
            return View();
        }

        //
        // POST: /Sucursal/Create

        [HttpPost]
        public ActionResult Create(Sucursal obSucursal)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    db.Mant(obSucursal, 1);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Sucursal/Edit/5

        public ActionResult Edit(int id)
        {

            Sucursal objSucursal = new Sucursal();
            objSucursal = db.GetSucursalListById(id);

            ViewBag.IdBanco = new SelectList(objBanco.GetBancoList(), "IdBanco", "Nombre",objSucursal.IdBanco);
            return View(objSucursal);
        }

        //
        // POST: /Sucursal/Edit/5

        [HttpPost]
        public ActionResult Edit(Sucursal obSucursal)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    obSucursal.FecRegistro = DateTime.Today;
                    ViewBag.IdBanco = new SelectList(objBanco.GetBancoList(), "IdBanco", "Nombre", obSucursal.IdBanco);
                    db.Mant(obSucursal, 2);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Sucursal/Delete/5

        public ActionResult Delete(int id)
        {


            Sucursal objSucursal = new Sucursal();
            objSucursal = db.GetSucursalListById(id);

            ViewBag.IdBanco = new SelectList(objBanco.GetBancoList(), "IdBanco", "Nombre", objSucursal.IdBanco);

            return View(objSucursal);
        }

        //
        // POST: /Sucursal/Delete/5

        [HttpPost]
        public ActionResult Delete(Sucursal obSucursal)
        {
            try
            {
                // TODO: Add delete logic here
                if (ModelState.IsValid)
                {
                    ViewBag.IdBanco = new SelectList(objBanco.GetBancoList(), "IdBanco", "Nombre", obSucursal.IdBanco);
                    db.Mant(obSucursal, 3);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
