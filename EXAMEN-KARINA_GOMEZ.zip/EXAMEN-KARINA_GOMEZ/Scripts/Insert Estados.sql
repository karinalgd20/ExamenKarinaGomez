

INSERT INTO TB_ESTADO(Descripcion)
VALUES('Pagada')

INSERT INTO TB_ESTADO(Descripcion)
VALUES('Declinada')

INSERT INTO TB_ESTADO(Descripcion)
VALUES('Fallida')

INSERT INTO TB_ESTADO(Descripcion)
VALUES('Anulada')